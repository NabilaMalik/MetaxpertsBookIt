package com.example.order_booking_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
